package com.campusfp.controlador;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import com.campusfp.main.Json_Parser;
import com.campusfp.main.Persona;
import com.campusfp.main.StaXParser;
import com.campusfp.main.Txt;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.StageStyle;

public class MainController {

	static public List<Persona> listaPersonasXML = new ArrayList<Persona>();
	static public List<Persona> listaPersonasJSON = new ArrayList<Persona>();

	@FXML
	public ImageView btn_xml, btn_json, btn_txt, btn_salir;
	public AnchorPane xml_container, json_container, txt_container;
	public Button btn_saludar, btn_agregar_xml, btn_agregar_json, btn_agregar_txt;
	public TextArea mostrar_xml, mostrar_json, mostrar_txt,txt_escribir;
	public TextField xml_nombre_input, xml_edad_input, xml_ciudad_input, xml_salario_input;
	public TextField json_nombre_input, json_edad_input, json_ciudad_input, json_salario_input;

	@FXML
	public void btn_Handler(MouseEvent event) {
		if (event.getTarget() == btn_xml) {
			xml_container.toFront();
		}
		if (event.getTarget() == btn_json) {
			json_container.toFront();
		}

		if (event.getTarget() == btn_txt) {
			txt_container.toFront();
		}

		if (event.getTarget() == btn_salir) {
			System.exit(0);
		}

	}

	@FXML
	public void leerXML() {

		StaXParser parser = new StaXParser();
		if (listaPersonasXML.size() > 0) {
			parser.actualizarXML("archivo.xml", listaPersonasXML);
		}

		List<Persona> listaPersonas = parser.lecturaArchivo("archivo.xml");
		mostrar_xml.setText(null);
		for (Persona persona : listaPersonas) {
			mostrar_xml.appendText(persona.toString());
		}

		listaPersonasXML = new ArrayList<Persona>();

	}

	public void agregarXML() {

		String nombre = xml_nombre_input.getText().toString();
		String edad = xml_edad_input.getText().toString();
		String ciudad = xml_ciudad_input.getText().toString();
		String salario = xml_salario_input.getText().toString();

		if (nombre.equals("") || edad.equals("") || ciudad.equals("") || salario.equals("")) {
			System.out.println("Debes rellenar todos los campos para introducir un elemento nuevo");
		} else {
			listaPersonasXML.add(new Persona(nombre, edad, ciudad, salario));
			System.out.println("Persona a�adida correctamente");
			xml_nombre_input.setText("");
			xml_edad_input.setText("");
			xml_ciudad_input.setText("");
			xml_salario_input.setText("");

		}

	}

	public void leerJSON() {

		Json_Parser parser = new Json_Parser();
		List <Persona> listaPersonas = new ArrayList<Persona>();
		listaPersonas = parser.leerJSON("archivo.json");
		
		if (listaPersonasJSON.size() > 0) {
			listaPersonas.addAll(listaPersonasJSON);
			parser.escribirJSON("archivo.json", listaPersonas);
		}

		mostrar_json.setText(null);
		for (Persona p : listaPersonas) {
			mostrar_json.appendText(p.toString());
		}
		
		parser.mostrarJSON("archivo.json");
		
		listaPersonasJSON = new ArrayList<Persona>();

	}
	
	public void agregarJSON() {

		String nombre = json_nombre_input.getText().toString();
		String edad = json_edad_input.getText().toString();
		String ciudad = json_ciudad_input.getText().toString();
		String salario = json_salario_input.getText().toString();

		if (nombre.equals("") || edad.equals("") || ciudad.equals("") || salario.equals("")) {
			System.out.println("Debes rellenar todos los campos para introducir un elemento nuevo");
		} else {
			listaPersonasJSON.add(new Persona(nombre, edad, ciudad, salario));
			System.out.println("Persona a�adida correctamente");
			json_nombre_input.setText("");
			json_edad_input.setText("");
			json_ciudad_input.setText("");
			json_salario_input.setText("");

		}

	}

	public void leerTXT() {
		Txt archivoTxt = new Txt();
		
		String contenido = archivoTxt.leer("archivo.txt");
		txt_escribir.setText(null);
		mostrar_txt.setText(contenido);
	}
	
	public void agregarTXT() {
		Txt archivoTxt = new Txt();
		String contenido = txt_escribir.getText();
		
		archivoTxt.escribir("archivo.txt", contenido);
		txt_escribir.setText(null);
		
	}

}
