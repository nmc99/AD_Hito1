package com.campusfp.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Txt {

	public String leer(String nomArchivo) {
		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;
		String resultado = "";

		try {
			archivo = new File(nomArchivo);
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);

			String linea;

			while ((linea = br.readLine()) != null) {
				resultado += linea + "\n";
			}
		} catch (Exception e) {

		} finally {
			try {
				if (null != fr) {
					fr.close();
				}
			} catch (Exception e2) {

			}
		}
		return resultado;
	}

	public static void main(String[] arg) {
		Txt archivo = new Txt();

		

		
		archivo.escribir("archivo.txt", "JAJA VALE");
		String hola = archivo.leer("archivo.txt");
		System.out.println(hola);
	}

	public void escribir(String nomArchivo, String contenido) {

		FileWriter fichero = null;
		PrintWriter pw = null;
		try {
			fichero = new FileWriter(nomArchivo,true);
			pw = new PrintWriter(fichero);
			pw.println("\n"+contenido);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// Nuevamente aprovechamos el finally para
				// asegurarnos que se cierra el fichero.
				if (null != fichero)
					fichero.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

}
