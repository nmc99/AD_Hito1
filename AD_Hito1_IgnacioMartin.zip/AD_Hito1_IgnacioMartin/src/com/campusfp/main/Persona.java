package com.campusfp.main;

public class Persona {
	private String nombre;
	private String edad;
	private String ciudad;
	private String salario;
	
	public Persona() {
		
	}

	public Persona(String nombre, String edad, String ciudad, String salario) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.ciudad = ciudad;
		this.salario = salario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEdad() {
		return edad;
	}

	public void setEdad(String edad) {
		this.edad = edad;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getSalario() {
		return salario;
	}

	public void setSalario(String salario) {
		this.salario = salario;
	}

	@Override
	public String toString() {
		return "Nombre: "+nombre+ " Edad: "+edad+" Ciudad: "+ciudad+" Salario: "+salario+"\n\n";
	}

}
