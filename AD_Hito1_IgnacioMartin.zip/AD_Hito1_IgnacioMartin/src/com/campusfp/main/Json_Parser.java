package com.campusfp.main;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Json_Parser {

	public static void main(String[] args) {
		Json_Parser parser = new Json_Parser();

		parser.escribirJSON("archivo.json", parser.leerJSON("archivo.json"));

	}

	public List<Persona> leerJSON(String archivo) {
		List<Persona> listaPersonasJson = new ArrayList<Persona>();

		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader(archivo)) {

			Object obj = jsonParser.parse(reader);

			JSONArray listaPersonas = (JSONArray) obj;
			listaPersonas.forEach(persona -> parsearPersona((JSONObject) persona, listaPersonasJson));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return listaPersonasJson;
	}

	public static void parsearPersona(JSONObject persona, List<Persona> listaPersonas) {
		JSONObject p = (JSONObject) persona.get("persona");
		List<Persona> listaFinal = new ArrayList<Persona>();

		String nombre = (String) p.get("nombre");
		String edad = (String) p.get("edad");
		String ciudad = (String) p.get("ciudad");
		String salario = (String) p.get("salario");

		Persona per = new Persona(nombre, edad, ciudad, salario);
		listaPersonas.add(per);
	}

	public void escribirJSON(String archivo, List<Persona> listaPersonas) {
		JSONArray listadoFinal = new JSONArray();

		for (Persona p : listaPersonas) {
			JSONObject detallesPersona = new JSONObject();
			detallesPersona.put("nombre", p.getNombre());
			detallesPersona.put("edad", p.getEdad());
			detallesPersona.put("ciudad", p.getCiudad());
			detallesPersona.put("salario", p.getSalario());

			JSONObject persona = new JSONObject();
			persona.put("persona", detallesPersona);
			listadoFinal.add(persona);
		}

		try (FileWriter file = new FileWriter(archivo)) {

			file.write(listadoFinal.toJSONString());
			file.flush();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String mostrarJSON(String archivo) {
		JSONParser jsonParser = new JSONParser();
		String resultado = "";

		try (FileReader reader = new FileReader(archivo)) {

			Object obj = jsonParser.parse(reader);

			JSONArray listaPersonas = (JSONArray) obj;
			resultado = listaPersonas.toJSONString();
			System.out.println(listaPersonas);
		}catch(Exception e) {
			
		}
		return resultado;
	}

}
