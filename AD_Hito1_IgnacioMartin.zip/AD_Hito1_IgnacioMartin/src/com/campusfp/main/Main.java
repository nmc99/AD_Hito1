package com.campusfp.main;

import java.io.IOException;
import java.util.List;

import com.sun.glass.ui.Window.EventHandler;
import com.sun.javafx.geom.AreaOp.XorOp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;

public class Main extends Application {

	double xOffset = 0; 
	double yOffset = 0;

	@Override
	public void start(Stage app) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource("../vista/main.fxml"));

		root.setOnMousePressed(new javafx.event.EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				xOffset = event.getSceneX();
				yOffset = event.getSceneY();

			}
		});

		root.setOnMouseDragged(new javafx.event.EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				app.setX(event.getScreenX() - xOffset);
				app.setY(event.getScreenY() - yOffset);
			}
		});

		Scene scene = new Scene(root, 800, 400, Color.TRANSPARENT);
		scene.getRoot().setStyle("-fx-background-color: transparent");
		app.initStyle(StageStyle.TRANSPARENT);
		app.setScene(scene);
		app.show();

	}

	public static void main(String[] args) {
		launch(args);
	}
}
